# Introduction
The Alerts.in.ua API Client is a Python library that simplifies access to the alerts.in.ua API service. It provides real-time information about air raid alerts and other potential threats.



# Installation
To install the Alerts.in.ua API Client, run the following command in your terminal:

```bash
pip install alerts_in_ua
```



# Usage

⚠️ Before you can use this library, you need to obtain an API token by submitting an [API request form](https://alerts.in.ua/api-request).

Here's an basic example of how to use the library to get a list of active alerts:

Async:
```python
import asyncio
from alerts_in_ua import AsyncClient as AsyncAlertsClient

async def main():
    # Initialize the client with your token
    alerts_client = AsyncAlertsClient(token="your_token")
    
    # Get the active alerts
    active_alerts = await alerts_client.get_active_alerts()
    print(active_alerts)


# Run the asynchronous function
asyncio.run(main())

```
or sync:
```python
from alerts_in_ua import Client as AlertsClient

alerts_client = AlertsClient(token="your_token")

# Get the active alerts
active_alerts = alerts_client.get_active_alerts()
print(active_alerts)
```

Since 0.4.0 every alert also carries an alert level (`red` / `yellow`) and the threats currently open within it:
```python
for alert in active_alerts.get_yellow_alerts():
    print(alert.location_title, [threat.threat_type for threat in alert.threats])
```
See [Alert levels and threats](#alert-levels-and-threats) for details.

# Alerts 

Alerts class is a collection of alerts and provides various methods to filter and access these alerts.

When user call `client.get_active_alerts()` it returns `Alerts` class.
## Methods

### filter(*args: str) -> List[Alert]
This method filters the alerts based on the given parameters.

```python
filtered_alerts = active_alerts.filter('location_oblast', 'Донецька область','alert_type','air_raid')
```
In this example, filtered_alerts will contain all the air raid alerts that have the location oblast as 'Донецька область'.

### get_alerts_by_location_title(location_title: str) -> List[Alert]
This method returns all the alerts from specified location.

```python
kyiv_alerts = active_alerts.get_alerts_by_location_title('м. Київ')
```

### get_air_raid_alerts() -> List[Alert]
This method returns all the alerts that are of alert type 'air_raid'.
```python 
air_raid_alerts = active_alerts.get_air_raid_alerts()
```

### get_oblast_alerts() -> List[Alert]
This method returns all the alerts that are of location type 'oblast'.

```python
oblast_alerts = active_alerts.get_oblast_alerts()
```

### get_raion_alerts() -> List[Alert]
This method returns all the alerts that are of location type 'raion'.
```python
raion_alerts = active_alerts.get_raion_alerts()
```

### get_hromada_alerts() -> List[Alert]
This method returns all the alerts that are of location type 'hromada'.
```python
hromada_alerts = active_alerts.get_hromada_alerts()
```

### get_city_alerts() -> List[Alert]
This method returns all the alerts that are of location type 'city'.

```python
city_alerts = active_alerts.get_city_alerts()
```

### get_alerts_by_alert_type(alert_type: str) -> List[Alert]
This method returns all the alerts that are of the given alert type.

```python
artillery_shelling_alerts = active_alerts.get_alerts_by_alert_type('artillery_shelling')
```

### get_alerts_by_location_type(location_type: str) -> List[Alert]
This method returns all the alerts that are of the given location type.

```python
urban_location_alerts = active_alerts.get_alerts_by_location_type('raion')
```

### get_alerts_by_oblast(oblast_title: str) -> List[Alert]
This method returns all the alerts that are of the given oblast title.

```python
donetsk_oblast_alerts = active_alerts.get_alerts_by_oblast('Донецька область')
```

### get_alerts_by_location_uid(location_uid: str) -> List[Alert]
This method returns all the alerts that have the given location uid.
```python
location_uid_alerts = active_alerts.get_alerts_by_location_uid('123456')
```

### get_artillery_shelling_alerts() -> List[Alert]
This method returns all the alerts that are of alert type 'artillery_shelling'.
```python 
artillery_shelling_alerts = active_alerts.get_artillery_shelling_alerts()
```

### get_urban_fights_alerts() -> List[Alert]
This method returns all the alerts that are of alert type 'urban_fights'.
```python 
urban_fights_alerts = active_alerts.get_urban_fights_alerts()
```

### get_nuclear_alerts() -> List[Alert]
This method returns all the alerts that are of alert type 'nuclear'.
```python 
nuclear_alerts = active_alerts.get_nuclear_alerts()
```

### get_chemical_alerts() -> List[Alert]
This method returns all the alerts that are of alert type 'chemical'.
```python 
chemical_alerts = active_alerts.get_chemical_alerts()
```

### get_alerts_by_alert_level(alert_level: str) -> List[Alert]
This method returns all the alerts with the given alert level (`red` or `yellow`).

```python
yellow_alerts = active_alerts.get_alerts_by_alert_level('yellow')
```

### get_red_alerts() -> List[Alert]
This method returns all the alerts with the red alert level.

```python
red_alerts = active_alerts.get_red_alerts()
```

### get_yellow_alerts() -> List[Alert]
This method returns all the alerts with the yellow alert level.

```python
yellow_alerts = active_alerts.get_yellow_alerts()
```

### get_alerts_with_threat_type(threat_type: str) -> List[Alert]
This method returns all the alerts that currently have an open threat of the given type
(`tactic_aircraft_activity`, `strategic_aircraft_activity`, `mig31k_departure`, `ballistic_missiles`,
`cruise_missiles`, `unspecified_missiles`, `drones`, `guided_aerial_bombs`, `air_defense`, `unknown`).

```python
drone_alerts = active_alerts.get_alerts_with_threat_type('drones')
```

### get_all_alerts() -> List[Alert]
This method returns all alerts.
```python 
all_alerts = active_alerts.get_all_alerts()
```
or you can use shortcut:
```python 
for alert in active_alerts:
    print(alert)
```
### get_last_updated_at() -> datetime.datetime
This method returns the datetime object representing the time when the alert information was last updated (Kyiv timezone).
```python
last_updated_at = alerts.get_last_updated_at()
```

### get_disclaimer() -> str
This method returns the disclaimer associated with the alert information.
```python
disclaimer = alerts.get_disclaimer()
```



# Alert levels and threats

Each `Alert` has an `alert_level` (`red` or `yellow`) and a list of `threats` — the individual threats
currently open within the alert. `threats` is an empty list when there are none.

```python
for alert in active_alerts:
    if alert.is_yellow():
        print(alert.location_title, "is on yellow level")
    for threat in alert.threats:
        print(threat.threat_type, threat.level, threat.started_at, threat.source_message)
```

`Alert` also has `location_title_en` and `country`. Helpers: `is_red()`, `is_yellow()`, `has_threats()`, `get_threats_by_type(threat_type)`.

`Threat` fields: `threat_type`, `level` (`red` / `yellow`), `started_at` (datetime in Kyiv time),
`source_message` (original wording from the source, may be `None`). Helpers: `is_red()`, `is_yellow()`.

Threat types: `tactic_aircraft_activity`, `strategic_aircraft_activity`, `mig31k_departure`, `ballistic_missiles`,
`cruise_missiles`, `unspecified_missiles`, `drones`, `guided_aerial_bombs`, `air_defense`, `unknown`.

A threat's level is independent of its alert's level: a `yellow` alert can carry a `red` threat.
Alerts from `get_alerts_history()` have `alert_level` but no `threats`, since threats only list what is open right now.

# Running tests

```bash
python -m unittest discover -s tests -t .
```

Live tests against the API are skipped unless a token is provided:

```bash
ALERTS_IN_UA_TOKEN=your_token python -m unittest tests.test_live
```

# Changelog

### 0.4.0
- `Alert.alert_level` (`red` / `yellow`) with `is_red()` / `is_yellow()`.
- `Alert.threats`: list of `Threat` objects (`threat_type`, `level`, `started_at`, `source_message`), plus `has_threats()` and `get_threats_by_type()`.
- `Alerts.get_alerts_by_alert_level()`, `get_red_alerts()`, `get_yellow_alerts()`, `get_alerts_with_threat_type()`.
- `Alert.location_title_en` and `Alert.country`.
- Unit tests and opt-in live API tests.

# License
MIT 2023
